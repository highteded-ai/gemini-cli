import React from 'react';
import { Helmet } from 'react-helmet';
import HedPreferences from './HedPreferences';
import AdminDashboard from './AdminDashboard';

export default function App(){
  return (
    <>
      <Helmet>
        <title>Hed Today Introduction: Engineering Tomorrow Infrastructure Today</title>
      </Helmet>
      <div>
        <header>
          <h1>Hed Today Introduction: Engineering Tomorrow Infrastructure Today</h1>
        </header>
        <main>
          <HedPreferences />
          <hr style={{ margin:'40px 0' }}/>
          <AdminDashboard />
        </main>
      </div>
    </>
  );
}