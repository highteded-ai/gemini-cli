import React,{useState} from 'react';
export default function HedPreferences(){
  const [email,setEmail]=useState('');
  const [prefs,setPrefs]=useState({productUpdates:true,tips:true,events:false,promotions:false,surveys:false});
  const [msg,setMsg]=useState('');
  const toggle=(k)=>setPrefs(s=>({...s,[k]:!s[k]}));
  async function submit(e){e.preventDefault();setMsg('Saving...');
    try{const res=await fetch((import.meta.env.VITE_API_URL||'')+'/api/preferences',
      {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,prefs})});
      if(!res.ok)throw new Error('save failed');
      setMsg('Preferences saved — check your email for confirmation.');
    }catch(err){setMsg('Error saving preferences.');}
  }
  return (
    <section>
      <h2>Manage Your Email Preferences</h2>
      <form onSubmit={submit}>
        <label>Your email<input type="email" required value={email} onChange={e=>setEmail(e.target.value)} /></label>
        <div>
          <label><input type="checkbox" checked={prefs.productUpdates} onChange={()=>toggle('productUpdates')}/> Product Updates</label>
          <label><input type="checkbox" checked={prefs.tips} onChange={()=>toggle('tips')}/> Learning Tools & Tips</label>
          <label><input type="checkbox" checked={prefs.events} onChange={()=>toggle('events')}/> Events & Webinars</label>
          <label><input type="checkbox" checked={prefs.promotions} onChange={()=>toggle('promotions')}/> Promotions</label>
          <label><input type="checkbox" checked={prefs.surveys} onChange={()=>toggle('surveys')}/> Surveys</label>
        </div>
        <button type="submit">Save Preferences</button>
      </form>
      <p>{msg}</p>
    </section>
  );
}