import React,{useState} from 'react';
export default function AdminDashboard(){
  const [list,setList]=useState([]);
  const [token,setToken]=useState('');
  async function fetchPrefs(){
    const res=await fetch((import.meta.env.VITE_API_URL||'')+'/api/admin/preferences',{headers:{'x-admin-token':token}});
    const data=await res.json(); setList(data||[]);
  }
  return (<section>
    <h2>Admin — Recent Preferences</h2>
    <label>Admin token<input value={token} onChange={e=>setToken(e.target.value)}/></label>
    <button onClick={fetchPrefs}>Load</button>
    <ul>{list.map(p=><li key={p.id}><strong>{p.email}</strong> — {JSON.stringify(p.prefs)}</li>)}</ul>
  </section>);
}