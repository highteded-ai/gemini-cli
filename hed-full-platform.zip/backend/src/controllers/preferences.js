const db = require('../../db/pg');
const mailer = require('../utils/mailer');
const { v4: uuidv4 } = require('uuid');

const savePreferences = async (req, res) => {
  try {
    const { email, prefs } = req.body;
    if (!email) return res.status(400).json({ error: 'email required' });
    const now = new Date().toISOString();
    const id = uuidv4();
    const query = `INSERT INTO preferences (id, email, prefs, updated_at)
      VALUES ($1,$2,$3,$4)
      ON CONFLICT (email) DO UPDATE SET prefs=$3, updated_at=$4 RETURNING id,email,prefs,updated_at`;
    const values = [id,email,JSON.stringify(prefs||{}),now];
    const { rows } = await db.query(query, values);
    await mailer.sendPreferenceConfirmation(email,prefs);
    res.json({ok:true,data:rows[0]});
  } catch (err) { console.error(err); res.status(500).json({ error:'server error' }); }
};

const getPreferences = async (req,res)=>{try{
  const { email } = req.params;
  const { rows } = await db.query('SELECT id,email,prefs,updated_at FROM preferences WHERE email=$1',[email]);
  if(!rows.length) return res.status(404).json({ error:'not found' });
  res.json(rows[0]);
}catch(err){console.error(err);res.status(500).json({ error:'server error' });}};

const adminList = async (req,res)=>{try{
  if(req.header('x-admin-token')!==process.env.ADMIN_TOKEN) return res.status(403).json({ error:'forbidden' });
  const { rows } = await db.query('SELECT id,email,prefs,updated_at FROM preferences ORDER BY updated_at DESC LIMIT 100');
  res.json(rows);
}catch(err){console.error(err);res.status(500).json({ error:'server error' });}};

module.exports={savePreferences,getPreferences,adminList};