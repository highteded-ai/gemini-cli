const express = require('express');
const router = express.Router();
const prefs = require('../controllers/preferences');

router.post('/preferences', prefs.savePreferences);
router.get('/preferences/:email', prefs.getPreferences);
router.get('/admin/preferences', prefs.adminList);
module.exports = router;