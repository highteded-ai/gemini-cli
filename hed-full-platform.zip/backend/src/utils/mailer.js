const nodemailer = require('nodemailer');
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: parseInt(process.env.SMTP_PORT||'587',10),
  secure: process.env.SMTP_SECURE==='true',
  auth:{ user:process.env.SMTP_USER, pass:process.env.SMTP_PASS }
});

async function sendPreferenceConfirmation(toEmail,prefs){
  const subject='Hed Today Introduction: Engineering Tomorrow Infrastructure Today - Preferences Updated';
  const text=`Your preferences were updated: ${JSON.stringify(prefs||{})}`;
  const html=`<p>Your preferences were updated:</p><pre>${JSON.stringify(prefs||{},null,2)}</pre>`;
  await transporter.sendMail({ from:process.env.EMAIL_FROM, to:toEmail, subject, text, html });
}
module.exports={sendPreferenceConfirmation};