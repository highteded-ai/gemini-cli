require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const bodyParser = require('body-parser');
const apiRoutes = require('./src/routes/api');

const app = express();
app.use(helmet());
app.use(cors());
app.use(bodyParser.json());
app.use(rateLimit({ windowMs: 60000, max: 120 }));
app.use('/api', apiRoutes);
const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Hed backend listening on ${PORT}`));